#!/usr/bin/env python3
"""
快速配置修改工具
"""

import json
import sys
import os
from pathlib import Path

# 添加src目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def get_config_file():
    """获取配置文件路径"""
    return Path.home() / '.terminal_translator' / 'config.json'

def load_config():
    """加载配置"""
    config_file = get_config_file()
    if config_file.exists():
        with open(config_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_config(config):
    """保存配置"""
    config_file = get_config_file()
    config_file.parent.mkdir(exist_ok=True)
    with open(config_file, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    print(f"✅ 配置已保存: {config_file}")

def set_language(lang_code):
    """设置目标语言"""
    config = load_config()
    if 'translation' not in config:
        config['translation'] = {}
    config['translation']['target_language'] = lang_code
    save_config(config)
    
    languages = {
        'zh-CN': '简体中文',
        'zh-TW': '繁体中文',
        'ja': '日语',
        'ko': '韩语',
        'en': '英语',
        'fr': '法语',
        'de': '德语'
    }
    lang_name = languages.get(lang_code, lang_code)
    print(f"🌐 目标语言已设置为: {lang_name} ({lang_code})")

def set_display_mode(mode):
    """设置显示模式 - 精简版只支持newline"""
    if mode != 'newline':
        print(f"⚠️  精简版只支持newline模式，已自动设置为newline")
        mode = 'newline'
    
    config = load_config()
    if 'display' not in config:
        config['display'] = {}
    config['display']['mode'] = mode
    save_config(config)
    
    print(f"🎨 显示模式已设置为: 换行模式 (newline)")

def set_engine(engine):
    """设置翻译引擎 - 精简版只支持google"""
    if engine != 'google':
        print(f"⚠️  精简版只支持Google翻译，已自动设置为google")
        engine = 'google'
    
    config = load_config()
    if 'translation' not in config:
        config['translation'] = {}
    config['translation']['engine'] = engine
    save_config(config)
    
    print(f"🔧 翻译引擎已设置为: Google翻译 (google)")

def set_color(color_type, color):
    """设置颜色"""
    config = load_config()
    if 'display' not in config:
        config['display'] = {}
    config['display'][f'color_{color_type}'] = color
    save_config(config)
    print(f"🎨 {color_type}颜色已设置为: {color}")

def show_current_config():
    """显示当前配置"""
    config = load_config()
    print("📋 当前配置:")
    print("-" * 30)
    
    if 'translation' in config:
        print("🌐 翻译设置:")
        print(f"  目标语言: {config['translation'].get('target_language', 'zh-CN')}")
        print(f"  翻译引擎: {config['translation'].get('engine', 'google')}")
    
    if 'display' in config:
        print("🎨 显示设置:")
        print(f"  显示模式: {config['display'].get('mode', 'newline')}")
        print(f"  原文颜色: {config['display'].get('color_original', 'white')}")
        print(f"  译文颜色: {config['display'].get('color_translation', 'cyan')}")
    
    print("-" * 30)

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("🔧 终端翻译器快速配置工具")
        print("=" * 40)
        show_current_config()
        print("\n📖 使用方法:")
        print("python quick_config.py <选项> <值>")
        print("\n🎯 可用选项:")
        print("  lang <语言代码>     - 设置目标语言")
        print("  mode <显示模式>     - 设置显示模式") 
        print("  engine <翻译引擎>   - 设置翻译引擎")
        print("  color <类型> <颜色> - 设置颜色")
        print("  show               - 显示当前配置")
        print("\n💡 示例:")
        print("  python quick_config.py lang ja          # 设置为日语")
        print("  python quick_config.py mode newline     # 设置为换行模式(默认)")
        print("  python quick_config.py engine google    # 设置为Google翻译(默认)")
        print("  python quick_config.py color translation green  # 设置译文颜色为绿色")
        print("  python quick_config.py show             # 显示当前配置")
        print("\n🌐 支持的语言: zh-CN, zh-TW, ja, ko, en, fr, de")
        print("🎨 支持的模式: newline (精简版只支持换行模式)")
        print("🔧 支持的引擎: google (精简版只支持Google翻译)")
        print("🌈 支持的颜色: white, red, green, yellow, blue, magenta, cyan")
        return
    
    command = sys.argv[1].lower()
    
    if command == 'lang' and len(sys.argv) >= 3:
        set_language(sys.argv[2])
    elif command == 'mode' and len(sys.argv) >= 3:
        set_display_mode(sys.argv[2])
    elif command == 'engine' and len(sys.argv) >= 3:
        set_engine(sys.argv[2])
    elif command == 'color' and len(sys.argv) >= 4:
        set_color(sys.argv[2], sys.argv[3])
    elif command == 'show':
        show_current_config()
    else:
        print("❌ 无效的选项或参数不足")
        print("使用 'python quick_config.py' 查看帮助")

if __name__ == "__main__":
    main()