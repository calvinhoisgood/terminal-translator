"""
翻译API集成模块 - 精简版
只支持Google翻译
"""

import re
from typing import Optional
from functools import lru_cache
import requests


class TranslationError(Exception):
    """翻译错误异常"""
    pass


class GoogleTranslator:
    """Google翻译器（免费版，通过网页接口）"""
    
    def __init__(self, timeout: int = 10):
        self.timeout = timeout
        self.session = requests.Session()
        self.base_url = "https://translate.googleapis.com/translate_a/single"
    
    def translate(self, text: str, target_lang: str = "zh-CN", source_lang: str = "auto") -> str:
        """使用Google翻译API翻译文本"""
        if not text.strip():
            return ""
        
        params = {
            'client': 'gtx',
            'sl': source_lang,
            'tl': target_lang,
            'dt': 't',
            'q': text
        }
        
        try:
            response = self.session.get(
                self.base_url,
                params=params,
                timeout=self.timeout,
                headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            )
            response.raise_for_status()
            
            result = response.json()
            if result and result[0]:
                # 提取翻译结果
                translated_parts = []
                for part in result[0]:
                    if part[0]:
                        translated_parts.append(part[0])
                return ''.join(translated_parts)
            
        except Exception as e:
            raise TranslationError(f"Google翻译失败: {e}")
        
        return text
    
    def is_available(self) -> bool:
        """检查翻译服务是否可用"""
        try:
            # 测试翻译一个简单的词
            result = self.translate("hello", "zh-CN", "en")
            return len(result) > 0
        except:
            return False


class TranslationManager:
    """翻译管理器 - 精简版"""
    
    def __init__(self, config=None):
        self.config = config
        self.translator = GoogleTranslator()
        self._translation_cache = {}
    
    def translate(self, text: str, target_lang: Optional[str] = None, source_lang: str = "auto") -> str:
        """翻译文本"""
        if not text or not text.strip():
            return text
        
        # 使用配置中的目标语言
        if target_lang is None and self.config:
            target_lang = self.config.get('translation.target_language', 'zh-CN')
        elif target_lang is None:
            target_lang = 'zh-CN'
        
        # 检查缓存
        cache_key = f"{text}:{source_lang}:{target_lang}"
        if cache_key in self._translation_cache:
            return self._translation_cache[cache_key]
        
        try:
            result = self.translator.translate(text, target_lang, source_lang)
            
            # 缓存结果
            if len(self._translation_cache) < 1000:  # 限制缓存大小
                self._translation_cache[cache_key] = result
            
            return result
        except Exception as e:
            print(f"翻译失败: {e}")
            return text
    
    def get_available_engines(self):
        """获取可用的翻译引擎"""
        return ['google']
    
    def is_available(self) -> bool:
        """检查翻译服务是否可用"""
        return self.translator.is_available()


# 文本识别函数
def is_english_text(text: str) -> bool:
    """判断文本是否主要是英文"""
    if not text or len(text.strip()) < 3:
        return False
    
    # 移除常见的非字母字符
    clean_text = re.sub(r'[\d\s\-_\./\\:=<>()\[\]{}"\']', '', text)
    
    if len(clean_text) == 0:
        return False
    
    # 计算英文字符比例
    english_chars = len(re.findall(r'[a-zA-Z]', clean_text))
    total_chars = len(clean_text)
    
    # 如果英文字符比例超过70%，认为是英文文本
    return (english_chars / total_chars) >= 0.7


def should_translate(text: str) -> bool:
    """判断是否应该翻译该文本"""
    if not text or len(text.strip()) < 3:
        return False
    
    # 检查是否是英文
    if not is_english_text(text):
        return False
    
    # 排除一些不需要翻译的内容
    exclude_patterns = [
        r'^[\w\-_]+\s*[:=]\s*[\w\-_/\.]+$',  # 配置项格式
        r'^\w+://\S+$',  # URL
        r'^/[\w\-_/\.]+$',  # 文件路径
        r'^[A-Z]:\\[\w\-_/\\.]+$',  # Windows路径
        r'^\d+(\.\d+)*$',  # 版本号
        r'^[a-fA-F0-9]{8,}$',  # 哈希值
    ]
    
    for pattern in exclude_patterns:
        if re.match(pattern, text.strip()):
            return False
    
    return True