"""
主翻译器模块 - 精简版
只支持主动翻译模式 (--realtime)
"""

import sys
import os
import argparse
import signal
import subprocess
import re
from typing import Optional

# 添加src目录到路径
sys.path.insert(0, os.path.dirname(__file__))

from config_manager import ConfigManager
from translation_apis import TranslationManager, should_translate
from display_formatter import DisplayFormatter


class TerminalTranslator:
    """终端翻译器主类 - 精简版"""
    
    def __init__(self, config_file: Optional[str] = None):
        """初始化终端翻译器"""
        self.config = ConfigManager(config_file)
        self.translation_manager = TranslationManager(self.config)
        self.display_formatter = DisplayFormatter(self.config)
        
        # 翻译缓存
        self.translation_cache = {}
        
        # 设置信号处理
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """信号处理器"""
        print(f"\n收到信号 {signum}，正在退出...")
        sys.exit(0)
    
    def _should_translate_line(self, line: str) -> bool:
        """判断某行是否应该翻译"""
        if not self.config.get('translation.auto_translate', True):
            return False
        
        line_stripped = line.strip()
        
        # 跳过空行
        if not line_stripped:
            return False
        
        # 跳过太短的行
        min_length = self.config.get('translation.translate_threshold', 5)
        if len(line_stripped) < min_length:
            return False
        
        # 跳过命令提示符行
        if self._is_prompt_line(line_stripped):
            return False
        
        # 跳过纯数字、路径等
        if re.match(r'^[\d\s\-/\\:.~$#>]+$', line_stripped):
            return False
        
        # 使用通用的翻译判断逻辑
        return should_translate(line_stripped)
    
    def _is_prompt_line(self, line: str) -> bool:
        """判断是否是命令提示符行"""
        # 常见的提示符模式
        prompt_patterns = [
            r'^\w+@\w+:.*\$\s*$',  # user@host:path$
            r'^\$\s*$',             # $
            r'^#\s*$',              # #
            r'^>\s*$',              # >
            r'^\[\w+@\w+.*\]\$\s*$', # [user@host path]$
        ]
        
        for pattern in prompt_patterns:
            if re.match(pattern, line):
                return True
        return False
    
    def _process_output_line(self, line: str) -> str:
        """处理输出行 - 主动翻译模式"""
        
        # 检查是否需要翻译
        if not self._should_translate_line(line):
            return line
        
        line_stripped = line.strip()
        
        # 检查缓存
        if line_stripped in self.translation_cache:
            translation = self.translation_cache[line_stripped]
        else:
            # 同步翻译以实现主动翻译
            try:
                translation = self.translation_manager.translate(
                    line_stripped,
                    target_lang=self.config.get('translation.target_language', 'zh-CN')
                )
                # 缓存结果
                self.translation_cache[line_stripped] = translation
                
            except Exception as e:
                print(f"翻译失败: {e}")
                return line
        
        # 使用换行模式格式化输出
        formatted_output = self.display_formatter.format_newline(line_stripped, translation)
        return formatted_output
    
    def start_realtime_translation(self, command: str):
        """启动实时翻译模式"""
        print("[信息] 启动实时翻译模式 (主动翻译)...")
        print(f"[信息] 翻译引擎: {self.config.get('translation.engine', 'google')}")
        print(f"[信息] 目标语言: {self.config.get('translation.target_language', 'zh-CN')}")
        print(f"[信息] 显示模式: {self.config.get('display.mode', 'newline')}")
        print("[信息] ✨ 所有英文内容将自动翻译为中文！")
        print("-" * 60)
        
        try:
            print(f"🚀 正在执行: {command}")
            print("-" * 40)
            
            # 执行命令并实时翻译输出
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='ignore',
                bufsize=1,
                universal_newlines=True
            )
            
            # 实时处理输出
            for line in process.stdout:
                if line.strip():  # 跳过空行
                    translated_line = self._process_output_line(line.rstrip())
                    print(translated_line)
                else:
                    print()
            
            process.wait()
            
        except KeyboardInterrupt:
            print("\n[信息] 用户中断翻译")
        except Exception as e:
            print(f"[错误] 执行命令时出错: {e}")
        finally:
            print("-" * 60)
            print("[信息] 实时翻译结束")
    
    def show_info(self):
        """显示翻译器信息"""
        print("终端沉浸式翻译器 - 精简版")
        print("=" * 40)
        print(f"翻译引擎: {self.config.get('translation.engine', 'google')}")
        print(f"目标语言: {self.config.get('translation.target_language', 'zh-CN')}")
        print(f"显示模式: 换行模式")
        print(f"配置文件: {self.config.config_file}")
        print("=" * 40)


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='终端沉浸式翻译器 - 精简版',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python translator.py --realtime "dir"            # 翻译dir命令输出
  python translator.py --realtime "python --help" # 翻译Python帮助信息
  python translator.py --realtime "git status"    # 翻译Git状态信息

注意: 命令需要用引号包裹！
        """
    )
    
    # 主要功能参数
    parser.add_argument('-r', '--realtime', type=str, metavar='COMMAND',
                       help='主动翻译模式：执行命令并实时翻译输出')
    
    # 其他选项
    parser.add_argument('--config', type=str, metavar='FILE',
                       help='指定配置文件路径')
    parser.add_argument('--info', action='store_true',
                       help='显示翻译器信息')
    
    args = parser.parse_args()
    
    # 创建翻译器实例
    try:
        translator = TerminalTranslator(config_file=args.config)
    except Exception as e:
        print(f"初始化翻译器失败: {e}")
        sys.exit(1)
    
    # 执行相应功能
    if args.info:
        translator.show_info()
    elif args.realtime:
        translator.start_realtime_translation(args.realtime)
    else:
        # 显示帮助信息
        parser.print_help()
        print("\n💡 推荐使用主动翻译模式：")
        print("  python translator.py --realtime \"你的命令\"")


if __name__ == "__main__":
    main()