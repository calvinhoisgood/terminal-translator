"""
配置管理模块
负责管理终端翻译器的各种配置项
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional


class ConfigManager:
    """配置管理器类"""
    
    def __init__(self, config_file: Optional[str] = None):
        """
        初始化配置管理器
        
        Args:
            config_file: 配置文件路径，如果为None则使用默认路径
        """
        self.config_file = config_file or self._get_default_config_path()
        self.config = self._load_default_config()
        self._load_user_config()
    
    def _get_default_config_path(self) -> str:
        """获取默认配置文件路径"""
        # 优先使用用户主目录下的配置文件
        home_config = Path.home() / '.terminal_translator' / 'config.json'
        if home_config.exists():
            return str(home_config)
        
        # 如果用户配置文件不存在，返回用户配置文件路径（将会被创建）
        return str(home_config)
    
    def _load_default_config(self) -> Dict[str, Any]:
        """加载默认配置"""
        return {
            # 翻译设置
            "translation": {
                "target_language": "zh-CN",
                "source_language": "auto",
                "engine": "google",  # 只支持google
                "auto_translate": True,
                "translate_threshold": 5,  # 最小翻译字符数
            },
            
            # 显示设置
            "display": {
                "mode": "newline",  # 只支持newline
                "color_original": "white",
                "color_translation": "cyan",
            },
        }
    
    def _load_user_config(self):
        """加载用户配置文件"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    self._merge_config(self.config, user_config)
        except (json.JSONDecodeError, IOError) as e:
            print(f"警告: 加载配置文件失败: {e}")
    
    def _merge_config(self, base: Dict[str, Any], override: Dict[str, Any]):
        """递归合并配置"""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._merge_config(base[key], value)
            else:
                base[key] = value
    
    def get(self, key_path: str, default=None) -> Any:
        """
        获取配置值
        
        Args:
            key_path: 配置键路径，使用点号分隔，如 'translation.target_language'
            default: 默认值
            
        Returns:
            配置值
        """
        keys = key_path.split('.')
        value = self.config
        
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key_path: str, value: Any):
        """
        设置配置值
        
        Args:
            key_path: 配置键路径
            value: 配置值
        """
        keys = key_path.split('.')
        config = self.config
        
        # 导航到目标位置
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        # 设置值
        config[keys[-1]] = value
    
    def save(self):
        """保存配置到文件"""
        try:
            # 确保配置目录存在
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
        except IOError as e:
            print(f"保存配置文件失败: {e}")
    
    def reset_to_defaults(self):
        """重置为默认配置"""
        self.config = self._load_default_config()
    
    def get_all(self) -> Dict[str, Any]:
        """获取所有配置"""
        return self.config.copy()
    
    def is_translation_enabled(self) -> bool:
        """检查翻译是否启用"""
        return self.get('translation.auto_translate', True)
    
    def get_target_language(self) -> str:
        """获取目标语言"""
        return self.get('translation.target_language', 'zh-CN')
    
    def get_translation_engine(self) -> str:
        """获取翻译引擎"""
        return self.get('translation.engine', 'google')
    
    def get_display_mode(self) -> str:
        """获取显示模式"""
        return self.get('display.mode', 'below')


# 全局配置实例
config = ConfigManager()


if __name__ == "__main__":
    # 测试配置管理器
    print("测试配置管理器...")
    
    # 测试获取配置
    print(f"目标语言: {config.get('translation.target_language')}")
    print(f"翻译引擎: {config.get('translation.engine')}")
    print(f"显示模式: {config.get('display.mode')}")
    
    # 测试设置配置
    config.set('translation.target_language', 'ja')
    print(f"修改后的目标语言: {config.get('translation.target_language')}")
    
    # 重置配置
    config.reset_to_defaults()
    print(f"重置后的目标语言: {config.get('translation.target_language')}")
    
    print("配置管理器测试完成！")