"""
显示格式化模块 - 精简版
只支持换行显示模式
"""

from colorama import init, Fore, Style

# 初始化colorama
init(autoreset=True)


class DisplayFormatter:
    """显示格式化器 - 精简版"""
    
    def __init__(self, config_manager=None):
        self.config = config_manager
        self.color_map = {
            'red': Fore.RED,
            'green': Fore.GREEN,
            'yellow': Fore.YELLOW,
            'blue': Fore.BLUE,
            'magenta': Fore.MAGENTA,
            'cyan': Fore.CYAN,
            'white': Fore.WHITE,
            'black': Fore.BLACK,
            'reset': Style.RESET_ALL,
        }
    
    def _get_color(self, color_name: str) -> str:
        """获取颜色代码"""
        return self.color_map.get(color_name.lower(), '')
    
    def format_newline(self, original: str, translation: str) -> str:
        """
        换行显示模式：译文显示在原文下一行
        格式：
        original
        translation
        """
        if not self.config:
            original_color = Fore.WHITE
            translation_color = Fore.CYAN
        else:
            original_color = self._get_color(self.config.get('display.color_original', 'white'))
            translation_color = self._get_color(self.config.get('display.color_translation', 'cyan'))
        
        lines = []
        
        # 原文行
        lines.append(f"{original_color}{original}{Style.RESET_ALL}")
        
        # 译文行（如果存在且不同于原文）
        if translation and translation.strip() != original.strip():
            lines.append(f"{translation_color}{translation}{Style.RESET_ALL}")
        
        return '\n'.join(lines)
    
    def format_output(self, original: str, translation: str, mode: str = 'newline') -> str:
        """
        格式化输出 - 只支持换行模式
        """
        # 始终使用换行模式
        return self.format_newline(original, translation)